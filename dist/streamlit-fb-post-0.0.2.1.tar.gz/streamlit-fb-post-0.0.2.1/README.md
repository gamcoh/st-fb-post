# st-chat

Streamlit Component, for Facebook Post UI

authors - [@gamcoh](https://github.com/gamcoh) 

## Installation

Install `streamlit-fb-post` with pip
```bash
pip install streamlit-fb-post
```

usage, import the `message` function from `streamlit_fb_post`
```py
import streamlit as st
from streamlit_fb_post import post

post("My message") 
post("Hello bot!", is_user=True)
```
   
