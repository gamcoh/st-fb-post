import os
from typing import List, Optional, Union

import streamlit.components.v1 as components

_RELEASE = True
COMPONENT_NAME = "streamlit_fb_post"

if _RELEASE:  # use the build instead of development if release is true
    root_dir = os.path.dirname(os.path.abspath(__file__))
    build_dir = os.path.join(root_dir, "frontend/build")

    _streamlit_fb_post = components.declare_component(
        COMPONENT_NAME,
        path = build_dir
    )
else:
    _streamlit_fb_post = components.declare_component(
        COMPONENT_NAME,
        url = "http://localhost:3000"
    )

def post(text: str, 
         legend: str,
         link: str,
         picture: Optional[Union[List[str], str]] = None,
         key: Optional[str] = None):
    """Create a facebook post.

    Args:
        text (str): The text of the post.
        picture (Optional[Union[List[str], str]], optional): The images that we want to render. Defaults to None.
        key (Optional[str], optional): A unique key for the component. Defaults to None.
    """
    _streamlit_fb_post(text=text, picture=picture, legend=legend, link=link, key=key)


if not _RELEASE:
    post("Bonjour ! Peut-on consommer ce vinaigre pour pessah svp Merci à vous ☺️", legend="le lundi tel", link="https://www.facebook.com/le.lundi.tel/posts/10156975490583929")
    post("Bonjour, est ce que ce produit frites surgelées MC Cain just au four express est Ok ? Merci d'avance pour la réponse et Hag Sameah😊", legend="21h30", link="https://www.facebook.com/21h30/posts/10156975490583929", picture=["https://scontent-cdt1-1.xx.fbcdn.net/v/t39.30808-6/278172002_10222769978381183_4841831622050085090_n.jpg?stp=dst-jpg_s600x600&_nc_cat=106&ccb=1-5&_nc_sid=5cd70e&_nc_ohc=cqjWBCLqt78AX9KkIIU&_nc_ht=scontent-cdt1-1.xx&oh=00_AT8HNJMNKCo1s1yCBcqidoDBQn5MIjZQUd5_8Oo7AclHnw&oe=62597D51", "https://scontent-cdt1-1.xx.fbcdn.net/v/t39.30808-6/277812773_10222769978941197_2577448024873019307_n.jpg?stp=dst-jpg_s600x600&_nc_cat=109&ccb=1-5&_nc_sid=5cd70e&_nc_ohc=BmO5Vl0SHmwAX9nv0EN&_nc_ht=scontent-cdt1-1.xx&oh=00_AT8WbfkSElbDIX7Z-Cr4RdqpQNaAlDuUOliG6Wazlgut8g&oe=62595B0C"])
    post("Bonjour est-ce que c'est autorisé ce lait entier lactel ?? Merci", legend="5 j", link="https://www.facebook.com/5j/posts/10156975490583929", picture="https://scontent-cdg2-1.xx.fbcdn.net/v/t39.30808-6/277733968_10158766395034646_5428360111244538274_n.jpg?stp=dst-jpg_p526x296&_nc_cat=102&ccb=1-5&_nc_sid=5cd70e&_nc_ohc=7b17RGu5bNQAX-3o8CL&tn=BAJj7UPOrflMlHYD&_nc_ht=scontent-cdg2-1.xx&oh=00_AT8gJUXJnIB7K8yMCV0-SYGnTDdrsIMp8aBKyAijyfO_bw&oe=62589BA9")
